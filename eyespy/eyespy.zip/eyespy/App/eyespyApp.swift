//
//  eyespyApp.swift
//  eyespy
//
//  Created by Alex Huynh on 11/18/24.
//

import SwiftUI

@main
struct eyespyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
